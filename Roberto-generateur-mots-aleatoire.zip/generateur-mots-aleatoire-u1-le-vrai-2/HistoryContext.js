import React, { createContext, useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const HistoryContext = createContext();

export const HistoryProvider = ({ children }) => {
  const [history, setHistory] = useState([]);

  useEffect(() => {
    loadHistory();
  }, []);

  useEffect(() => {
    saveHistory();
  }, [history, saveHistory]);

  const saveHistory = useCallback(async () => {
    try {
      const jsonValue = JSON.stringify(history);
      await AsyncStorage.setItem('@history', jsonValue);
    } catch (e) {
      console.error('Error saving history', e);
    }
  }, [history]);

  const loadHistory = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem('@history');
      if (jsonValue != null) {
        setHistory(JSON.parse(jsonValue));
      }
    } catch (e) {
      console.error('Error loading history', e);
    }
  };

  const addWordsToHistory = (words) => {
    const date = new Date();
    const newEntries = words.map((word) => ({ word, date }));
    setHistory((prevHistory) => [...prevHistory, ...newEntries]);
  };

  const removeHistoryItem = (word) => {
    setHistory((prevHistory) =>
      prevHistory.filter((item) => item.word !== word)
    );
  };

  const clearHistory = () => {
    setHistory([]);
  };

  return (
    <HistoryContext.Provider
      value={{ history, addWordsToHistory, removeHistoryItem, clearHistory }}>
      {children}
    </HistoryContext.Provider>
  );
};
