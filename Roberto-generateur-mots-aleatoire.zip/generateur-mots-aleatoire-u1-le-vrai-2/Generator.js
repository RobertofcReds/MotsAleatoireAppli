import React, { useState, useEffect, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ImageBackground,
  ActivityIndicator,
  Clipboard,
  Alert,
  ScrollView,
} from 'react-native';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { HistoryContext } from './HistoryContext';
import { ParametersContext } from './ParametersContext';
import { FavoritesContext } from './FavoritesContext';

export default function Generator({ navigation, route }) {
  const [words, setWords] = useState([]);
  const [loading, setLoading] = useState(false);
  const { addWordsToHistory } = useContext(HistoryContext);
  const { parameters } = useContext(ParametersContext);
  const { addFavorite } = useContext(FavoritesContext);
  const fromHome = route.params?.fromHome || false;

  useEffect(() => {
    const fetchStoredWords = async () => {
      if (fromHome) {
        const storedWords = await AsyncStorage.getItem('generatedWords');
        if (storedWords) {
          setWords(JSON.parse(storedWords));
        }
      }
    };
    fetchStoredWords();
  }, [fromHome]);

  const generateWords = async () => {
    const { numberOfWords, language, minLetters, maxLetters } = parameters;
    setLoading(true);

    try {
      const fetchAndFilterWords = async (remainingTries = 3) => {
        const response = await axios.get(
          `https://random-word-api.herokuapp.com/word?number=${
            numberOfWords * 2
          }&lang=${language}`
        );
        let newWords = response.data;

        newWords = newWords.filter(
          (word) => word.length >= minLetters && word.length <= maxLetters
        );

        if (newWords.length >= numberOfWords) {
          newWords = newWords.slice(0, numberOfWords);
          setWords(newWords);
          addWordsToHistory(newWords);
          await AsyncStorage.setItem(
            'generatedWords',
            JSON.stringify(newWords)
          );
        } else if (remainingTries > 0) {
          return fetchAndFilterWords(remainingTries - 1);
        } else {
          setWords(newWords);
          addWordsToHistory(newWords);
          await AsyncStorage.setItem(
            'generatedWords',
            JSON.stringify(newWords)
          );
          if (newWords.length === 0) {
            Alert.alert(
              'Impossible de trouver des mots qui correspondent à vos paramètres'
            );
          } else {
            Alert.alert(
              'Impossible de trouver des mots qui conviennent à vos paramètres'
            );
          }
        }
      };

      await fetchAndFilterWords();
    } catch (error) {
      console.error('Error fetching words: ', error);
    } finally {
      setLoading(false);
    }
  };

  const saveAllToFavorites = () => {
    words.forEach((word) => addFavorite(word));
  };

  const copyWordsToClipboard = () => {
    Clipboard.setString(words.join(', '));
    Alert.alert('Copié', 'Les mots ont été copiés dans le presse-papier.');
  };

  return (
    <ImageBackground
      source={require('./fonts/rm224-mind-24.jpg')}
      style={styles.background}>
      <View style={styles.container}>
        <TouchableOpacity
          style={styles.para}
          onPress={() => navigation.navigate('Parameters')}>
          <Image source={require('./icon/parametres.png')} style={styles.img} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.histo}
          onPress={() => navigation.navigate('History')}>
          <Image
            source={require('./icon/bouton-dhorloge-historique.png')}
            style={styles.img}
          />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.favo}
          onPress={() => navigation.navigate('Favorites')}>
          <Image source={require('./icon/favori.png')} style={styles.img} />
        </TouchableOpacity>

        <TouchableOpacity onPress={generateWords}>
          <Image source={require('./icon/melanger.png')} style={styles.img} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.goldButton} onPress={generateWords}>
          <Text style={styles.buttonText}>Générer</Text>
        </TouchableOpacity>
        {loading ? (
          <ActivityIndicator size="large" color="#0000ff" />
        ) : (
          <ScrollView contentContainerStyle={styles.wordList}>
            {words.map((word, index) => (
              <Text key={index} style={styles.word}>
                {word}
              </Text>
            ))}
          </ScrollView>
        )}
        <View style={styles.footer}>
          <TouchableOpacity
            style={styles.goldButton}
            onPress={() => navigation.navigate('History')}>
            <Text style={styles.buttonText}>Historique</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.goldButton}
            onPress={() => navigation.navigate('Favorites')}>
            <Text style={styles.buttonText}>Favoris</Text>
          </TouchableOpacity>
        </View>

        {words.length > 0 && (
          <View style={styles.actionButtons}>
            <TouchableOpacity
              style={styles.saveButton}
              onPress={saveAllToFavorites}>
              <Image
                source={require('./icon2/favori-coeur.png')}
                style={styles.img}
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.copyButton}
              onPress={copyWordsToClipboard}>
              <Image
                source={require('./icon2/copier-lecriture.png')}
                style={styles.img}
              />
            </TouchableOpacity>
          </View>
        )}
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  img: {
    width: 40,
    height: 40,
  },
  favo: {
    position: 'absolute',
    bottom: 45,
    right: 35,
    minHeight: 70,
    minWidth: 40,
  },
  histo: {
    position: 'absolute',
    bottom: 45,
    left: 40,
    minHeight: 70,
    minWidth: 40,
  },
  para: {
    position: 'absolute',
    top: 10,
    right: 10,
    minWidth: 40,
    minHeight: 40,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 50,
  },
  wordList: {
    marginTop: 20,
    paddingBottom: 100,
    alignItems: 'center',
  },
  word: {
    fontSize: 20,
    marginVertical: 5,
    textAlign: 'center',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    position: 'absolute',
    bottom: 20,
    paddingHorizontal: 20,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 10,
    position: 'absolute',
    top: 6,
    left: 10,
  },
  saveButton: {
    padding: 4,
    borderRadius: 4,
  },
  copyButton: {
    marginLeft: 10,
    padding: 4,
    borderRadius: 4,
  },
  goldButton: {
    backgroundColor: 'blue',
    padding: 10,
    borderRadius: 20,
    marginVertical: 10,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});
