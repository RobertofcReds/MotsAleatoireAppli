import React from 'react';
import { View, Text, StyleSheet, ImageBackground } from 'react-native';

export default function About() {
  return (
    <ImageBackground
      source={require('./fonts/rm224-mind-24.jpg')}
      style={styles.background}>
      <View style={styles.container}>
        <Text style={styles.title}>À PROPOS DE L'APPLICATION</Text>
        <Text style={styles.content}>
          Cette application a été développée pour vous aider à générer des mots
          aléatoires. Vous pouvez ajuster les paramètres selon vos besoins et
          sauvegarder vos mots préférés.
        </Text>
        <Text style={styles.content}>
          Développeur: TILAHIZAFY Judicaël Roberto
        </Text>
        <Text style={styles.content}>
          E-mail: tilahizafyrobertojudicael@gmail.com
        </Text>
        <Text style={styles.content}>Version: 1.0.0 copyright @2024</Text>
        <Text style={styles.content}>Merci d'utiliser notre application !</Text>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 25,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
    color: 'blue',
  },
  content: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 10,
  },
});
