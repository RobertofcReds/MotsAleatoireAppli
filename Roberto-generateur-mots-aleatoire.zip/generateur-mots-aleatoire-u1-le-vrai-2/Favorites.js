import React, { useContext, useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  ImageBackground,
  Alert,
} from 'react-native';
import { AutoSizeText, ResizeTextMode } from 'react-native-auto-size-text';
import { FavoritesContext } from './FavoritesContext';

export default function Favorites() {
  const { favorites, removeFavorite, clearFavorites } =
    useContext(FavoritesContext);
  const [filteredFavorites, setFilteredFavorites] = useState([]);

  useEffect(() => {
    const sortedFavorites = [...favorites].sort(
      (a, b) => new Date(b.timestamp) - new Date(a.timestamp)
    );
    setFilteredFavorites(sortedFavorites.slice(0, 100));
  }, [favorites]);

  const formatDate = (date) => {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    const itemDate = new Date(date);

    if (itemDate.toDateString() === today.toDateString()) {
      return `aujourd'hui à ${itemDate.toLocaleTimeString('fr-FR')}`;
    } else if (itemDate.toDateString() === yesterday.toDateString()) {
      return `hier à ${itemDate.toLocaleTimeString('fr-FR')}`;
    } else {
      return `${itemDate.getDate()}/${
        itemDate.getMonth() + 1
      }/${itemDate.getFullYear()} à ${itemDate.toLocaleTimeString('fr-FR')}`;
    }
  };

  const confirmClearFavorites = () => {
    Alert.alert(
      'Confirmer',
      'Êtes-vous sûr de vouloir supprimer tous les favoris ?',
      [
        {
          text: 'Annuler',
          style: 'cancel',
        },
        {
          text: 'Oui',
          onPress: clearFavorites,
        },
      ]
    );
  };

  return (
    <ImageBackground
      source={require('./fonts/rm224-mind-24.jpg')}
      style={styles.background}>
      <View style={styles.container}>
        <FlatList
          data={filteredFavorites}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item }) => (
            <View style={styles.favoriteItem}>
              <AutoSizeText
                numberOfLines={1}
                minFontSize={14}
                fontSize={18}
                mode={ResizeTextMode.max_lines}
                style={styles.word}>
                {item.word}
              </AutoSizeText>
              <Text style={styles.timestamp}>
                {formatDate(new Date(item.timestamp))}
              </Text>
              <TouchableOpacity onPress={() => removeFavorite(item.word)}>
                <Image
                  source={require('./icon2/favori.png')}
                  style={styles.icon}
                />
              </TouchableOpacity>
            </View>
          )}
        />
        <TouchableOpacity
          style={styles.clearButton}
          onPress={confirmClearFavorites}>
          <Text style={styles.clearButtonText}>Supprimer tout</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  container: {
    flex: 1,
    padding: 20,
  },
  favoriteItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: 'blue',
  },
  word: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  timestamp: {
    fontSize: 12,
    color: 'blue',
  },
  icon: {
    width: 20,
    height: 20,
  },
  clearButton: {
    backgroundColor: 'red',
    padding: 10,
    borderRadius: 20,
    alignItems: 'center',
    marginVertical: 10,
  },
  clearButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});
