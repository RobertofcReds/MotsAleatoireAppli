import React, { createContext, useState } from 'react';

export const ParametersContext = createContext();

const defaultParameters = {
  numberOfWords: 2,
  language: 'en', // 'en' pour anglais, 'fr' pour français, etc.
  minLetters: 1,
  maxLetters: 10,
};

export const ParametersProvider = ({ children }) => {
  const [parameters, setParameters] = useState(defaultParameters);

  const resetParameters = () => {
    setParameters(defaultParameters);
  };

  return (
    <ParametersContext.Provider
      value={{ parameters, setParameters, resetParameters }}>
      {children}
    </ParametersContext.Provider>
  );
};
