import React, { createContext, useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const FavoritesContext = createContext();

export const FavoritesProvider = ({ children }) => {
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    loadFavorites();
  }, []);

  useEffect(() => {
    saveFavorites();
  }, [favorites, saveFavorites]);

  const saveFavorites = useCallback(async () => {
    try {
      const jsonValue = JSON.stringify(favorites);
      await AsyncStorage.setItem('@favorites', jsonValue);
    } catch (e) {
      console.error('Error saving favorites', e);
    }
  }, [favorites]);

  const loadFavorites = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem('@favorites');
      if (jsonValue != null) {
        setFavorites(JSON.parse(jsonValue));
      }
    } catch (e) {
      console.error('Error loading favorites', e);
    }
  };

  const addFavorite = (word) => {
    const newFavorite = { word, timestamp: new Date().toISOString() };
    setFavorites((prevFavorites) => [...prevFavorites, newFavorite]);
  };

  const removeFavorite = (word) => {
    setFavorites((prevFavorites) =>
      prevFavorites.filter((favorite) => favorite.word !== word)
    );
  };

  const clearFavorites = () => {
    setFavorites([]);
  };

  return (
    <FavoritesContext.Provider
      value={{ favorites, addFavorite, removeFavorite, clearFavorites }}>
      {children}
    </FavoritesContext.Provider>
  );
};
