import React, { useContext, useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Image,
  ImageBackground,
  Alert,
} from 'react-native';
import { AutoSizeText, ResizeTextMode } from 'react-native-auto-size-text';
import * as Clipboard from 'expo-clipboard';
import { HistoryContext } from './HistoryContext';

export default function History() {
  const { history, removeHistoryItem, clearHistory } =
    useContext(HistoryContext);
  const [filteredHistory, setFilteredHistory] = useState([]);

  useEffect(() => {
    const sortedHistory = [...history].sort(
      (a, b) => new Date(b.date) - new Date(a.date)
    );
    setFilteredHistory(sortedHistory.slice(0, 100));
  }, [history]);

  const copyToClipboard = (word) => {
    Clipboard.setString(word);
    Alert.alert('Copié', 'Mot copié dans le presse-papiers.');
  };

  const formatDate = (date) => {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return `aujourd'hui à ${date.toLocaleTimeString('fr-FR')}`;
    } else if (date.toDateString() === yesterday.toDateString()) {
      return `hier à ${date.toLocaleTimeString('fr-FR')}`;
    } else {
      return `${date.getDate()}/${
        date.getMonth() + 1
      }/${date.getFullYear()} à ${date.toLocaleTimeString('fr-FR')}`;
    }
  };

  const confirmClearHistory = () => {
    Alert.alert(
      'Confirmer',
      "Êtes-vous sûr de vouloir supprimer tout l'historique ?",
      [
        {
          text: 'Annuler',
          style: 'cancel',
        },
        {
          text: 'Oui',
          onPress: clearHistory,
        },
      ]
    );
  };

  return (
    <ImageBackground
      source={require('./fonts/rm224-mind-24.jpg')}
      style={styles.background}>
      <View style={styles.container}>
        <ScrollView>
          {filteredHistory.map((item, index) => (
            <View key={index} style={styles.historyItem}>
              <AutoSizeText
                numberOfLines={1}
                minFontSize={14}
                fontSize={18}
                mode={ResizeTextMode.max_lines}
                style={styles.word}>
                {item.word}
              </AutoSizeText>
              <Text style={styles.timestamp}>
                {formatDate(new Date(item.date))}
              </Text>
              <View style={styles.iconContainer}>
                <TouchableOpacity onPress={() => copyToClipboard(item.word)}>
                  <Image
                    source={require('./icon2/papier.png')}
                    style={styles.icon}
                  />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => removeHistoryItem(item.word)}>
                  <Image
                    source={require('./icon/supprimer.png')}
                    style={styles.icon}
                  />
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </ScrollView>
        <TouchableOpacity
          style={styles.clearButton}
          onPress={confirmClearHistory}>
          <Text style={styles.clearButtonText}>Supprimer tout</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  icon: {
    width: 20,
    height: 20,
    marginLeft: 10,
  },
  container: {
    flex: 1,
    padding: 20,
  },
  historyItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: 'blue',
  },
  word: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  timestamp: {
    fontSize: 12,
    color: 'blue',
  },
  iconContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  clearButton: {
    backgroundColor: 'red',
    padding: 10,
    borderRadius: 20,
    alignItems: 'center',
    marginVertical: 10,
  },
  clearButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});
