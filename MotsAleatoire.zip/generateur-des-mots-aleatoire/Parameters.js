import React, { useContext, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  ImageBackground,
} from 'react-native';
import { Picker } from '@react-native-picker/picker'; // Import correct
import { ParametersContext } from './ParametersContext';

export default function Parameters({ navigation }) {
  const { parameters, setParameters } = useContext(ParametersContext);
  const [numberOfWords, setNumberOfWords] = useState(parameters.numberOfWords);
  const [language, setLanguage] = useState(parameters.language);
  const [minLetters, setMinLetters] = useState(parameters.minLetters);
  const [maxLetters, setMaxLetters] = useState(parameters.maxLetters);

  const saveParameters = () => {
    setParameters({ numberOfWords, language, minLetters, maxLetters });
    navigation.goBack();
  };

  return (
    <ImageBackground
      source={require('./fonts/rm224-mind-24.jpg')}
      style={styles.background}>
      <View style={styles.container}>
        <Text style={styles.label}>Nombre de mots :</Text>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={String(numberOfWords)}
          onChangeText={(text) => setNumberOfWords(Number(text))}
        />

        <Text style={styles.label}>Langue :</Text>
        <Picker
          selectedValue={language}
          style={styles.input}
          onValueChange={(itemValue) => setLanguage(itemValue)}>
          <Picker.Item label="Anglais" value="en" />
          <Picker.Item label="Français" value="fr" />
        </Picker>

        <Text style={styles.label}>Longueur minimale :</Text>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={String(minLetters)}
          onChangeText={(text) => setMinLetters(Number(text))}
        />

        <Text style={styles.label}>Longueur maximale :</Text>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={String(maxLetters)}
          onChangeText={(text) => setMaxLetters(Number(text))}
        />

        <Button title="Sauvegarder" onPress={saveParameters} />
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  label: {
    fontSize: 18,
    marginBottom: 10,
  },
  input: {
    width: 200,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    marginBottom: 20,
    textAlign: 'center',
  },
});
