import React, { useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  ImageBackground,
} from 'react-native';
import { FavoritesContext } from './FavoritesContext';

export default function Favorites() {
  const { favorites, removeFavorite } = useContext(FavoritesContext);

  return (
    <ImageBackground
      source={require('./fonts/rm224-mind-24.jpg')}
      style={styles.background}>
      <View style={styles.container}>
        <FlatList
          data={favorites}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item }) => (
            <View style={styles.favoriteItem}>
              <Text style={styles.word}>{item.word}</Text>
              <Text style={styles.timestamp}>{item.timestamp}</Text>
              <TouchableOpacity onPress={() => removeFavorite(item.word)}>
                <Image
                  source={require('./icon/supprimer.png')}
                  style={styles.icon}
                />
              </TouchableOpacity>
            </View>
          )}
        />
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },

  container: {
    flex: 1,
    padding: 20,
  },
  favoriteItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  word: {
    fontSize: 18,
  },
  timestamp: {
    fontSize: 12,
    color: '#666',
  },
  icon: {
    width: 20,
    height: 20,
  },
});
