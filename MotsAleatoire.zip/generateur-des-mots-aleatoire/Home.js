import React from 'react';
import {
  View,
  Text,
  Button,
  StyleSheet,
  TouchableOpacity,
  Image,
  ImageBackground,
} from 'react-native';

export default function Home({ navigation }) {
  return (
    <ImageBackground
      source={require('./fonts/rm224-mind-24.jpg')}
      style={styles.background}>
      <View style={styles.container}>
        <TouchableOpacity
          style={styles.para}
          onPress={() => navigation.navigate('Parameters')}>
          <Image source={require('./icon/parametres.png')} style={styles.img} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.histo}
          onPress={() => navigation.navigate('History')}>
          <Image
            source={require('./icon/bouton-dhorloge-historique.png')}
            style={styles.img}
          />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.favo}
          onPress={() => navigation.navigate('Favorites')}>
          <Image source={require('./icon/favori.png')} style={styles.img} />
        </TouchableOpacity>

        <Text style={styles.title}>Bienvenue ! MOTS ALEATOIRE</Text>
        <Button
          title="Commencer"
          onPress={() => navigation.navigate('Generator')}
        />
        <View style={styles.footer}>
          <Button
            title="Historique"
            onPress={() => navigation.navigate('History')}
          />
          <Button
            title="Favoris"
            onPress={() => navigation.navigate('Favorites')}
          />
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },

  img: {
    width: 40,
    height: 40,
  },

  favo: {
    position: 'absolute',
    bottom: 35,
    right: 35,
    minHeight: 70,
    minWight: 40,
  },

  histo: {
    position: 'absolute',
    bottom: 35,
    left: 50,
    minHeight: 70,
    minWight: 40,
  },
  para: {
    position: 'absolute',
    top: 5,
    right: 10,
    minWight: 40,
    minHeight: 40,
  },

  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    position: 'absolute',
    bottom: 20,
    paddingHorizontal: 20,
  },
});
