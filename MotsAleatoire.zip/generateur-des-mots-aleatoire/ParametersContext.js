import React, { createContext, useState } from 'react';

export const ParametersContext = createContext();

export const ParametersProvider = ({ children }) => {
  const [parameters, setParameters] = useState({
    numberOfWords: 2,
    language: 'en', // 'en' pour anglais, 'fr' pour français
    minLetters: 1,
    maxLetters: 10,
  });

  return (
    <ParametersContext.Provider value={{ parameters, setParameters }}>
      {children}
    </ParametersContext.Provider>
  );
};
