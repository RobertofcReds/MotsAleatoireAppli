import React, { useContext } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Image,
  ImageBackground,
} from 'react-native';
import { HistoryContext } from './HistoryContext';

export default function History() {
  const { history, removeHistoryItem } = useContext(HistoryContext);

  return (
    <ImageBackground
      source={require('./fonts/rm224-mind-24.jpg')}
      style={styles.background}>
      <View style={styles.container}>
        <ScrollView>
          {history.map((item, index) => (
            <View key={index} style={styles.historyItem}>
              <Text style={styles.word}>{item.word}</Text>
              <Text style={styles.timestamp}>{item.date.toLocaleString()}</Text>
              <TouchableOpacity onPress={() => removeHistoryItem(item.word)}>
                <Image
                  source={require('./icon/supprimer.png')}
                  style={styles.icon}
                />
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  icon: {
    width: 20,
    height: 20,
  },
  container: {
    flex: 1,
    padding: 20,
  },
  historyItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  word: {
    fontSize: 18,
  },
  timestamp: {
    fontSize: 12,
    color: '#666',
  },
});
