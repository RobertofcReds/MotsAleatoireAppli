import 'react-native-gesture-handler';
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Home from './Home';
import Parameters from './Parameters';
import Generator from './Generator';
import History from './History';
import Favorites from './Favorites';
import { HistoryProvider } from './HistoryContext';
import { ParametersProvider } from './ParametersContext';
import { FavoritesProvider } from './FavoritesContext';

const Stack = createStackNavigator();

export default function App() {
  return (
    <HistoryProvider>
      <ParametersProvider>
        <FavoritesProvider>
          <NavigationContainer>
            <Stack.Navigator initialRouteName="Home">
              <Stack.Screen name="Home" component={Home} />
              <Stack.Screen name="Parameters" component={Parameters} />
              <Stack.Screen name="Generator" component={Generator} />
              <Stack.Screen name="History" component={History} />
              <Stack.Screen name="Favorites" component={Favorites} />
            </Stack.Navigator>
          </NavigationContainer>
        </FavoritesProvider>
      </ParametersProvider>
    </HistoryProvider>
  );
}
