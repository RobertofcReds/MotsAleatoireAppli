import React, { createContext, useState } from 'react';

export const HistoryContext = createContext();

export const HistoryProvider = ({ children }) => {
  const [history, setHistory] = useState([]);

  const addWordsToHistory = (words) => {
    const date = new Date();
    const newEntries = words.map((word) => ({ word, date }));

    setHistory((prevHistory) => {
      const updatedHistory = [...prevHistory, ...newEntries];

      if (updatedHistory.length > 100) {
        return updatedHistory.slice(updatedHistory.length - 100);
      }

      return updatedHistory;
    });
  };

  const removeHistoryItem = (word) => {
    setHistory((prevHistory) =>
      prevHistory.filter((item) => item.word !== word)
    );
  };

  return (
    <HistoryContext.Provider
      value={{ history, addWordsToHistory, removeHistoryItem }}>
      {children}
    </HistoryContext.Provider>
  );
};
