import React, { useState, useContext } from 'react';
import {
  View,
  Text,
  Button,
  StyleSheet,
  TouchableOpacity,
  Image,
  ImageBackground,
} from 'react-native';
import axios from 'axios';
import { HistoryContext } from './HistoryContext';
import { ParametersContext } from './ParametersContext';
import { FavoritesContext } from './FavoritesContext';

export default function Generator({ navigation }) {
  const [words, setWords] = useState([]);
  const { addWordsToHistory } = useContext(HistoryContext);
  const { parameters } = useContext(ParametersContext);
  const { addFavorite } = useContext(FavoritesContext);

  const generateWords = () => {
    const { numberOfWords, language, minLetters, maxLetters } = parameters;

    // Fonction pour récupérer des mots et les filtrer
    const fetchAndFilterWords = (remainingTries = 3) => {
      axios
        .get(
          `https://random-word-api.herokuapp.com/word?number=${
            numberOfWords * 2
          }&lang=${language}`
        )
        .then((response) => {
          let newWords = response.data;

          // Filtrer les mots en fonction de la longueur minimale et maximale
          newWords = newWords.filter(
            (word) => word.length >= minLetters && word.length <= maxLetters
          );

          if (newWords.length >= numberOfWords) {
            newWords = newWords.slice(0, numberOfWords);
            setWords(newWords);
            addWordsToHistory(newWords);
          } else if (remainingTries > 0) {
            fetchAndFilterWords(remainingTries - 1);
          } else {
            setWords(newWords); // Utiliser les mots obtenus même s'ils sont moins nombreux que nécessaire
            addWordsToHistory(newWords);
          }
        })
        .catch((error) => {
          console.error('Error fetching words: ', error);
        });
    };

    fetchAndFilterWords();
  };

  const saveAllToFavorites = () => {
    words.forEach((word) => addFavorite(word));
  };

  return (
    <ImageBackground
      source={require('./fonts/rm224-mind-24.jpg')}
      style={styles.background}>
      <View style={styles.container}>
        <TouchableOpacity
          style={styles.para}
          onPress={() => navigation.navigate('Parameters')}>
          <Image source={require('./icon/parametres.png')} style={styles.img} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.histo}
          onPress={() => navigation.navigate('History')}>
          <Image
            source={require('./icon/bouton-dhorloge-historique.png')}
            style={styles.img}
          />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.favo}
          onPress={() => navigation.navigate('Favorites')}>
          <Image source={require('./icon/favori.png')} style={styles.img} />
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.navigate('Generator')}>
          <Image source={require('./icon/melanger.png')} style={styles.img} />
        </TouchableOpacity>

        <Button title="Générer" onPress={generateWords} />
        {words.length > 0 && (
          <View style={styles.wordList}>
            {words.map((word, index) => (
              <Text key={index} style={styles.word}>
                {word}
              </Text>
            ))}
          </View>
        )}
        <View style={styles.footer}>
          <Button
            title="Historique"
            onPress={() => navigation.navigate('History')}
          />
          <Button
            title="Favoris"
            onPress={() => navigation.navigate('Favorites')}
          />
        </View>

        {words.length > 0 && (
          <TouchableOpacity
            style={styles.saveButton}
            onPress={saveAllToFavorites}>
            <Image source={require('./icon/favori1.png')} style={styles.img} />
          </TouchableOpacity>
        )}
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  img: {
    width: 40,
    height: 40,
  },
  favo: {
    position: 'absolute',
    bottom: 35,
    right: 35,
    minHeight: 70,
    minWidth: 40,
  },
  histo: {
    position: 'absolute',
    bottom: 35,
    left: 50,
    minHeight: 70,
    minWidth: 40,
  },
  para: {
    position: 'absolute',
    top: 5,
    right: 10,
    minWidth: 40,
    minHeight: 40,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  wordList: {
    marginTop: 20,
  },
  word: {
    fontSize: 15,
    marginVertical: 5,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    position: 'absolute',
    bottom: 20,
    paddingHorizontal: 20,
  },
  saveButton: {
    position: 'absolute',
    top: 5,
    left: 10,
    padding: 4,
    borderRadius: 4,
  },
});
