import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ImageBackground,
} from 'react-native';
import * as Sharing from 'expo-sharing';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function Home({ navigation }) {
  const [showEnterIcon, setShowEnterIcon] = useState(false);

  useEffect(() => {
    const checkGeneratedWords = async () => {
      const generatedWords = await AsyncStorage.getItem('generatedWords');
      if (generatedWords) {
        setShowEnterIcon(true);
      }
    };
    checkGeneratedWords();
  }, []);

  const shareApp = () => {
    // Exemple de fonctionnalité de partage
    Sharing.shareAsync("Lien ou fichier de l'application à partager", {
      dialogTitle: "Partager l'application",
    });
  };

  return (
    <ImageBackground
      source={require('./fonts/rm224-mind-24.jpg')}
      style={styles.background}>
      <View style={styles.container}>
        <TouchableOpacity
          style={styles.para}
          onPress={() => navigation.navigate('Parameters')}>
          <Image source={require('./icon/parametres.png')} style={styles.img} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.histo}
          onPress={() => navigation.navigate('History')}>
          <Image
            source={require('./icon/bouton-dhorloge-historique.png')}
            style={styles.img}
          />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.favo}
          onPress={() => navigation.navigate('Favorites')}>
          <Image source={require('./icon/favori.png')} style={styles.img} />
        </TouchableOpacity>

        {showEnterIcon && (
          <TouchableOpacity
            style={styles.enter}
            onPress={() =>
              navigation.navigate('Generator', { fromHome: true })
            }>
            <Image source={require('./icon2/entrer.png')} style={styles.img} />
          </TouchableOpacity>
        )}

        <TouchableOpacity
          style={styles.about}
          onPress={() => navigation.navigate('About')}>
          <Image source={require('./icon2/info.png')} style={styles.img} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.share} onPress={shareApp}>
          <Image source={require('./icon2/partager.png')} style={styles.img} />
        </TouchableOpacity>

        <Text style={styles.title}>Bienvenue ! MOTS ALEATOIRE</Text>

        <TouchableOpacity
          style={styles.goldButton}
          onPress={() => navigation.navigate('Generator')}>
          <Text style={styles.buttonCommencer}>COMMENCER</Text>
        </TouchableOpacity>

        <View style={styles.footer}>
          <TouchableOpacity
            style={styles.goldButton}
            onPress={() => navigation.navigate('History')}>
            <Text style={styles.buttonText}>Historique</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.goldButton}
            onPress={() => navigation.navigate('Favorites')}>
            <Text style={styles.buttonText}>Favoris</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  img: {
    width: 40,
    height: 40,
  },
  favo: {
    position: 'absolute',
    bottom: 45,
    right: 35,
    minHeight: 70,
    minWidth: 40,
  },
  histo: {
    position: 'absolute',
    bottom: 45,
    left: 40,
    minHeight: 70,
    minWidth: 40,
  },
  para: {
    position: 'absolute',
    top: 10,
    right: 10,
    minWidth: 40,
    minHeight: 40,
  },
  about: {
    position: 'absolute',
    top: 10,
    left: 80,
    minWidth: 40,
    minHeight: 40,
  },
  share: {
    position: 'absolute',
    top: 10,
    left: 10,
    minWidth: 40,
    minHeight: 40,
  },
  enter: {
    position: 'absolute',
    top: 10,
    right: 75,
    minWidth: 40,
    minHeight: 40,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 30,
    textAlign: 'center',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    position: 'absolute',
    bottom: 20,
    paddingHorizontal: 20,
  },
  goldButton: {
    backgroundColor: 'blue',
    padding: 10,
    borderRadius: 20,
    marginVertical: 10,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  buttonCommencer: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 20,
  },
});
